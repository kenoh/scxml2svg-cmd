#!/bin/bash

# to xhtml
xmlto xhtml manual.dbk


# to pdf
dblatex manual.dbk
